<<<<<<< HEAD
import { StrictMode, createContext, useContext, useState } from 'react'
=======
import { StrictMode } from 'react'
>>>>>>> 1f298558196103ba247230b0a0bb7a7411c72c6d
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

<<<<<<< HEAD
const AuthContext = createContext(null);
export function useAuth() {
  return useContext(AuthContext);
}

function AuthProvider({ children }) {
  const [accessToken, setAccessToken] = useState('');
  const [userName, setUserName] = useState('');
  const value = { accessToken, setAccessToken, userName, setUserName };
  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AuthProvider>
      <App />
    </AuthProvider>
=======
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
>>>>>>> 1f298558196103ba247230b0a0bb7a7411c72c6d
  </StrictMode>,
)
