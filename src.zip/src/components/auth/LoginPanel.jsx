import { useState } from 'react';
import Input from '../common/Input';
import Button from '../common/Button';
import SocialLoginButtons from './SocialLoginButtons';
import ProfileCompletionPanel from './ProfileCompletionPanel';
import SignUpPanel from './SignUpPanel';
import styles from './LoginPanel.module.css';
<<<<<<< HEAD
import { useAuth } from '../../main.jsx';

const API_BASE = 'http://localhost:1882';
=======
>>>>>>> 1f298558196103ba247230b0a0bb7a7411c72c6d

function LoginPanel({ onClose }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showProfileCompletion, setShowProfileCompletion] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
<<<<<<< HEAD
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const { setAccessToken, setUserName } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    try {
      const response = await fetch(API_BASE + '/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ homepageId: username, password }),
      });
      if (!response.ok) throw new Error('아이디 또는 비밀번호가 올바르지 않습니다.');
      const data = await response.json();
      if (data.accessToken) {
        setAccessToken(data.accessToken);
        setUserName(data.name || data.username || username);
        onClose();
      } else {
        throw new Error('로그인 처리 중 오류가 발생했습니다.');
      }
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setLoading(false);
    }
=======

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('정적 프로토타입입니다.\n실제 로그인 기능은 백엔드 연동 후 구현됩니다.');
>>>>>>> 1f298558196103ba247230b0a0bb7a7411c72c6d
  };

  const handleLinkClick = (action) => {
    alert(`${action} 기능은 구현 예정입니다.`);
  };

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.panel} onClick={(e) => e.stopPropagation()}>
        <div className={styles.panelHeader}>
          <h3 className={styles.title}>로그인</h3>
          <button className={styles.closeButton} onClick={onClose}>&times;</button>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.fieldRow}>
            <label htmlFor="username" className={styles.fieldLabel}>아 이 디</label>
            <input
              id="username"
              type="text"
              placeholder="아이디를 입력하세요"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={styles.fieldInput}
              required
            />
          </div>

          <div className={styles.fieldRow}>
            <label htmlFor="password" className={styles.fieldLabel}>비밀번호</label>
            <input
              id="password"
              type="password"
              placeholder="비밀번호를 입력하세요"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={styles.fieldInput}
              required
            />
          </div>

<<<<<<< HEAD
          {errorMsg && (
            <div className={styles.errorMsg}>{errorMsg}</div>
          )}

          <Button type="submit" variant="primary" size="lg" disabled={loading}>
            {loading ? '로그인 중...' : '로그인'}
=======
          <Button type="submit" variant="primary" size="lg">
            로그인
>>>>>>> 1f298558196103ba247230b0a0bb7a7411c72c6d
          </Button>

          <div className={styles.links}>
            <span
              className={styles.link}
              onClick={() => setShowSignUp(true)}
            >
              회원가입
            </span>
            <span
              className={styles.link}
              onClick={() => handleLinkClick('아이디 찾기')}
            >
              아이디 찾기
            </span>
            <span
              className={styles.link}
              onClick={() => handleLinkClick('비밀번호 찾기')}
            >
              비밀번호 찾기
            </span>
          </div>
        </form>

        <SocialLoginButtons />

        <div className={styles.info}>
          데모 버전입니다 &nbsp;|&nbsp;
          <span
            className={styles.link}
            onClick={() => setShowProfileCompletion(true)}
          >
            추가정보 입력 테스트
          </span>
        </div>
      </div>

      {showProfileCompletion && (
        <ProfileCompletionPanel onClose={() => setShowProfileCompletion(false)} />
      )}

      {showSignUp && (
        <SignUpPanel onClose={() => setShowSignUp(false)} />
      )}
    </div>
  );
}

export default LoginPanel;
