import { PROJECT_POSTS } from '../data/projectPosts';
import ProjectBoardList from '../components/board/ProjectBoardList';
import styles from './CommunityPage.module.css';

function ProjectsPage() {
  return (
    <div>
      <section className={styles.hero}>
        <div className={styles.heroContainer}>
          <h1 className={styles.heroTitle}>프로젝트</h1>
          <p className={styles.heroSubtitle}>프로젝트 관련 문의 및 소식을 확인하세요</p>
        </div>
      </section>

      <div className={styles.content}>
        <ProjectBoardList posts={PROJECT_POSTS} />
      </div>
    </div>
  );
}

export default ProjectsPage;
