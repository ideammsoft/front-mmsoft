import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

function OAuthCallbackPage() {
  const [params] = useSearchParams();
  const [msg, setMsg] = useState('SNS 로그인 처리 중...');
  const navigate = useNavigate();

  useEffect(() => {
    const code = params.get('code');
    if (!code) {
      setMsg('인증 코드가 없습니다. 다시 로그인해주세요.');
      setTimeout(() => navigate('/'), 2000);
      return;
    }

    fetch(`http://localhost:1882/api/auth/oauth2/exchange?code=${encodeURIComponent(code)}`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    })
      .then(res => {
        if (!res.ok) throw new Error('코드 교환 실패');
        return res.json();
      })
      .then(data => {
        const name = data.name || data.user?.name || 'SNS 사용자';
        localStorage.setItem('mmsoft_user', JSON.stringify({ name }));
        navigate('/');
      })
      .catch(() => {
        setMsg('SNS 로그인에 실패했습니다. 다시 시도해주세요.');
        setTimeout(() => navigate('/'), 2000);
      });
  }, [params, navigate]);

  return (
    <div style={{ textAlign: 'center', padding: '80px 20px', color: 'var(--color-text-light)' }}>
      <p>{msg}</p>
    </div>
  );
}

export default OAuthCallbackPage;
