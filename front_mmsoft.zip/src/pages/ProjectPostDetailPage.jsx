import { useParams, Link, useNavigate } from 'react-router-dom';
import { FaChevronLeft, FaUser, FaCalendar, FaEye, FaEdit, FaTrash } from 'react-icons/fa';
import { PROJECT_POSTS } from '../data/projectPosts';
import styles from './PostDetailPage.module.css';

function ProjectPostDetailPage() {
  const { postId } = useParams();
  const navigate = useNavigate();
  const post = PROJECT_POSTS.find(p => p.id === parseInt(postId));

  const loggedInId = (() => {
    try { return JSON.parse(localStorage.getItem('mmsoft_user'))?.homepageId || ''; } catch { return ''; }
  })();
  const canEdit = loggedInId === 'manyman' || loggedInId === 'manyman2';

  const handleDelete = () => {
    if (window.confirm('게시글을 삭제하시겠습니까?')) {
      alert('삭제되었습니다. (데모)');
      navigate('/projects');
    }
  };

  const handleEdit = () => {
    alert('수정 기능 (데모)');
  };

  if (!post) {
    return (
      <div className={styles.pageWrapper}>
        <div className={styles.notFound}>
          <h1 className={styles.notFoundTitle}>게시글을 찾을 수 없습니다</h1>
          <p className={styles.notFoundText}>
            요청하신 게시글이 존재하지 않거나 삭제되었습니다.
          </p>
          <Link to="/projects" className={styles.backButton}>
            <FaChevronLeft />
            목록으로 돌아가기
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.pageWrapper}>
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <span className={styles.categoryTag}>{post.category}</span>
          <h1 className={styles.title}>{post.title}</h1>
          <div className={styles.meta}>
            <span className={styles.metaItem}>
              <FaUser size={13} />
              {post.author}
            </span>
            <span className={styles.metaItem}>
              <FaCalendar size={13} />
              {post.date}
            </span>
            <span className={styles.metaItem}>
              <FaEye size={13} />
              조회 {post.views}
            </span>
          </div>
        </div>

        <div className={styles.content}>
          <p>{post.content}</p>
        </div>

        <div className={styles.footer}>
          <Link to="/projects" className={styles.backButton}>
            <FaChevronLeft />
            목록으로
          </Link>
          {canEdit && (
            <div className={styles.actions}>
              <button className={styles.editButton} onClick={handleEdit}>
                <FaEdit />
                수정
              </button>
              <button className={styles.deleteButton} onClick={handleDelete}>
                <FaTrash />
                삭제
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ProjectPostDetailPage;
