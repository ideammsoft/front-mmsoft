// 다운로드 항목 데이터
export const DOWNLOADS = [
  {
    id: 1,
    title: '[여러사람8.2] 고객관리 -5자리우편번호,도로명주소 적용',
    description: 'Windows 10/12 호환 설치 패키지',
    category: 'software',
    fileSize: '15MB',
    version: 'v8.2',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/man.exe',
    imageUrl: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=280&h=180&fit=crop&auto=format',
    content: '***** 설치방법\n[다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 문의 요망\n\n2. 주요성능 :\n고객을 효율적으로 관리해주는 고객관리 전문 프로그램 여러사람 v8.2 입니다.\n새 도로명 주소 및 개정된 우편번호와 전화지역번호 데이타 베이스를 가지고 있어서 편리하게 이용 할 수 있습니다.\n고객 입력폼에는 입력일자를 포함하여 성명, 직책, 주소, 회사/부서, 전화, 팩스, 휴대폰, e-mail, 비고, 그룹등 다양한 폼이 준비가 되어 있습니다.\n강력한 서치 엔진을 내장하여 입력 폼의 내용중 하나의 조건으로 빠르게 검색이 가능합니다.\n복합 검색이 가능하며 전화를 소프트웨어로 바로 걸어줄 수도 있습니다(LG UPlus 기업인터넷전화 가입시).\n특히 다양한 인쇄 옵션을 제공하여 우편 및 DM 발송에 편리한 여러 가지 기능을 제공합니다.'
  },
  {
    id: 2,
    title: '주택/빌라 관리비 정산 소프트웨어',
    description: 'Windows 10/14 호환 설치 패키지',
    category: 'software',
    fileSize: '9MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/SetupJiroJu.exe',
    imageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 문의요망\n\n2. 주요성능 :\n· 주택이나 빌라 관리비 정산 소프트웨어\n· 전기료(공동, 세대)\n· 수도료(전월, 현월, 톤당요금, 사용량기록)\n· 이월미납금 포함하여 잔액계산\n· 관리비명세서 출력\n· 호별 월사용리스트 출력\n· 입주자 현황 출력\n· 유선방송, 정화조요금, 수선비, 음식물수거비등 기타항목 정의가능\n· 세대별, 전체 문자메시지 전송가능\n· 지로출력-MICR용지, OCR용지 모두 사용 가능\n\n3. OS : Windows 95/98/NT/2000/2003/XP/Vista'
  },
  {
    id: 3,
    title: '[지로출력도우미4.1] 고객관리 및 지로용지출력',
    description: 'Windows 10/15 호환 설치 패키지',
    category: 'software',
    fileSize: '17MB',
    version: 'v4.1',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/jiro.exe',
    imageUrl: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=280&h=180&fit=crop&auto=format',
    content: '***** 설치방법\n[다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 문의요망\n\n2. 주요성능 :\n· 월별 금액 한꺼번에 입력 가능\n· 새 도로명주소와 구주소 모두 입력가능\n· MICR용지, OCR용지 모두 사용 가능\n· 입금자동 체크\n· 월별납입/미납자 리스트 출력 가능\n· 화일단위로 분류하여 입출력 가능\n· 입력시 회원번호 자동 증가\n· 새우편번호 5자리 적용\n· 집배코드 인쇄 및 집계표 작성(옵션)\n· 64비트에서 검색오류 수정됨\n· 범위선택 및 모두선택 인쇄 가능\n\n3. OS : Windows 95/98/NT/2000/2003/XP/Vista/7'
  },
  {
    id: 4,
    title: '<무료> [여러사람프리웨어v7.5]',
    description: 'Windows 10/17 호환 설치 패키지',
    category: 'software',
    fileSize: '12MB',
    version: 'v7.5',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/man745.exe',
    imageUrl: 'https://images.unsplash.com/photo-1542744173-05336fcc7ad4?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 본 프로그램은 1997년부터 판매용으로 제작된 프로그램이며 5천여 업체에서 구매해 주셨습니다. 2012년 당시 88,000원에 정상판매되던 제품입니다. 그동안 성원에 보답하고, 보다 많은 분들께 편의를 제공하고자 무료 버젼으로 전환하였습니다.\n\n2. 모든 기능은 정품과 같습니다.\n- 기존 구매 고객분들은 별도로 정식번호 등록을 해야 하는 불편이 없어졌습니다.\n\n3. 단, 기존 구매해주신 고객님과 신규 도입을 원하시는 분들께 불공평한 점은 있습니다. 이해해 주시기 바랍니다.\n\n4. 문의 바랍니다.\n저희에게 무료로 전환하면서 바라는 것은 저희 메뉴얼 서비스를 이용해 주셨으면 합니다. 메뉴얼 서비스를 구독해주시면 문자(90건), 문자(2000건)의 메뉴얼 서비스와 단체 회비(대기업)등의 서비스를 제공합니다.'
  },
  {
    id: 5,
    title: '<프리웨어> 아카데미플러스 - 학원/체육관/헬스장',
    description: 'Windows 10/19 호환 설치 패키지',
    category: 'software',
    fileSize: '15MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/setupaca.exe',
    imageUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n제품버젼: 아카데미플러스 V2017\n제품가격: 무료\n사용환경: Windows 95/98/NT/2000/2003/XP/Vista\n\n주요기능\n1. 학원생 정보 관리\n2. 카드(마그네틱)를 이용한 출석 관리\n3. 카드 긁으면 출석되었다는 메세지와 함께 학원생 신상정보가 보임\n4. 발신자 표시기를 이용해 전화가 오면 수강생 정보가 출력됨\n5. 가정통신문 같은 파일 첨부\n6. 이메일 발송\n7. 이메일 첨부파일에서 전체/부분적 다르게 보낼 수 있음\n8. 출석 기준에 따른 재원생 목록 조회\n9. 생일/기념일 이벤트 발생시 처리\n10. 자동/수동 출석 관리 및 출석체크 처리\n11. 각 학원생의 월/년 출석 현황을 한눈에 볼 수 있는 달력에 표시\n12. 학원생에 대한 문의 처리\n13. 학원생에 대한 메모 처리\n14. SMS 단체 메시지 발송가능\n15. 전체 이미지를 검색하는 기능'
  },
  {
    id: 6,
    title: '<프리웨어> 문자 발송기',
    description: 'Windows 10/20 호환 설치 패키지',
    category: 'software',
    fileSize: '7MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/moonj.exe',
    imageUrl: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=280&h=180&fit=crop&auto=format',
    content: '문자 발송기 입니다.\n문자보낼때 요금이 무료는 아니구요. 프로그램이 무료입니다.\n예약 발송 및 발송 문자 저장 등의 기능이 있습니다.\n\n회원가입 후 사용하세요.\n\n설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.'
  },
  {
    id: 7,
    title: '일취월장v2013 - 판매관리/세금계산서/거래명세표',
    description: 'Windows 10/21 호환 설치 패키지',
    category: 'software',
    fileSize: '11MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/SetupiL.exe',
    imageUrl: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 33만원(부가세포함)\n\n2. 주요성능 :\n· 거래명세표/세금계산서/입출금전표 입력 및 출력\n· 출력시 엑셀로 거래명세표, 세금계산서 출력(양식지가 없는 업체에서 간단히 출력)\n· 일반경비 입력 및 출력(계산되지 않는 장부)\n· 자손처리\n· 각종 집계 현황출력(기간, 거래처, 품목별)\n  - 매입/매출 현황\n  - 입금/출금 현황\n  - 미수/미지급금 현황\n  - 전체거래 현황\n  - 거래처별 집계\n  - 판매일보\n· 관리현황 출력\n· 청구서, 영수증서류 출력\n· 수식의 데이타 출력\n· 세금계산서 합계표 출력(세금신고용)\n· 프로그램 업그레이드 지원(자동 업데이트 메뉴)\n· 거래처 입력시 단어의 완성\n· 품목입력시 단가 및 규격 자동완성'
  },
  {
    id: 8,
    title: '우리동문v2017 -동문회 관리 프로그램',
    description: 'Windows 10/22 호환 설치 패키지',
    category: 'software',
    fileSize: '13MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/WooDong.exe',
    imageUrl: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 문의요망\n\n2. 주요성능 :\n· 기수, 그룹, 단체명등 코드입력 편리\n· 금년 생일을 조회하여 문자메시지나 라벨출력 가능\n· 입금처리시 장부와 연동하여 입력됨\n· 사진입력\n· 장부입력시 입력시킬 내용을 미리 입력해 놓고 선택가능\n· 잔액자동 계산\n· 월별 회비 한꺼번에 입력 가능\n· MICR용지, OCR용지 모두 사용 가능\n· 입금자동 체크\n· 월별납입/미납자 리스트 출력 가능\n· 화일단위로 분류하여 입출력 가능\n· 입력시 회원번호 자동 증가\n\n3. OS : Windows 95/98/NT/2000/2003/XP/Vista/7'
  },
  {
    id: 9,
    title: '[대장부 3.5] 간편장부 프로그램',
    description: 'Windows 10/23 호환 설치 패키지',
    category: 'software',
    fileSize: '4MB',
    version: 'v3.5',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/djb.exe',
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=280&h=180&fit=crop&auto=format',
    content: '1. 가 격 : 문의요망\n\n2. 주요성능 :\n· 일자별 입출금 입력이 편리함\n· 내역별로 검색 및 출력 가능\n· 엑셀로 전송 가능 - 엑셀에서 편집/출력\n· 월별합계, 누적합계를 한눈에 볼 수 있음\n· 년별로 데이타 별도 관리가능(내용별로도 별도 관리가능)\n\n3. OS : Windows 95/98/NT/2000/XP\n\n4. 설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.'
  },
  {
    id: 10,
    title: '네이버 매출관리/간편매출관리 v1.0',
    description: 'Windows 10/24 호환 설치 패키지',
    category: 'software',
    fileSize: '6MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/setnaver.exe',
    imageUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가격 : 문의요망\n\n2. 주요성능 :\n매출관리를 빠르고 쉽게 도와주는 매출관리 전문 프로그램 네이버매출 v1.0 입니다.\n고객 입력폼에는 고객명, 전화번호, 휴대폰 등의 폼이 준비가 되어 있습니다.\n강력한 서치 엔진을 내장하여 입력 폼의 내용 중 하나의 조건으로 빠르게 검색이 가능합니다.\n고객에 대한 일반적인 폼 입력이외에 적요도 상세하게 적을 수 있는 공간이 존재합니다.\n또한 고객에 대한 매출 누적금액이 자동으로 나타납니다.\n20가지종류의 통계자료를 열람하실 수 있습니다. 항상 사용해주셔서 감사드립니다.'
  },
  {
    id: 11,
    title: '[보험고객관리4.0]-자동차보험용',
    description: 'Windows 10/25 호환 설치 패키지',
    category: 'software',
    fileSize: '12MB',
    version: 'v4.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/bo_s.exe',
    imageUrl: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=280&h=180&fit=crop&auto=format',
    content: '1. 가 격 : 528,000원, 연관리비 55,000원\n\n2. 주요성능 :\n· 부서별/취급자별/보험사별 관리가 가능\n· 개인별 실적에 따른 그래프 출력 가능\n· 기간별 합계 금액/수수료등이 엑셀로 출력\n· 고객 DM발송\n· 암호화 기능(그래프등 관리자만 검색)\n\n3. OS : Windows 95/98/NT/2000/2003/XP/Vista/7\n\n4. 설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.'
  },
  {
    id: 12,
    title: '지로출력가스v3.0 -가스회사용 지로출력',
    description: 'Windows 10/26 호환 설치 패키지',
    category: 'software',
    fileSize: '12MB',
    version: 'v3.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/JiroGas.exe',
    imageUrl: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=280&h=180&fit=crop&auto=format',
    content: '설치방법 : [다운로드]를 눌러 "현재위치에서 실행" 또는 "열기" 선택\n*설치 중간에 나올 수 있는 등록오류는 <무시>를 누르시면 됩니다.\n\n1. 가 격 : 770,000원(연관리비 55,000원 - 1년에 한번)\n\n2. 주요성능 :\n· 월별 금액 한꺼번에 입력 가능\n· 전원검침, 당월검침 출력\n· 당월사용량 출력\n· 세금계산서 인쇄된 지로용지에 부가세 출력가능\n· MICR용지, OCR용지 모두 사용 가능\n· 입금자동 체크\n· 월별납입/미납자 리스트 출력 가능\n· 화일단위로 분류하여 입출력 가능\n· 입력시 회원번호 자동 증가\n\n3. OS : Windows 95/98/NT/2000/2003/XP/Vista/7'
  },
  {
    id: 13,
    title: '새도로명 주소 파일(5자리 우편번호적용)-2025년 4월',
    description: 'Windows 10/13 호환 설치 패키지',
    category: 'utility',
    fileSize: '91MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/zipDoro3.exe',
    imageUrl: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=280&h=180&fit=crop&auto=format',
    content: '도로명주소가 적용된 저희 제품 모두 사용하는 DB입니다.\n연회비를 납부하시는 여러사람, 지로출력도우미, 우리동문을 사용 고객께서 다운받아 설치하면 됩니다.\n\n** 새도로명주소는 600만건의 대용량 자료이기 때문에 프로그램과 별도로 설치 파일을 제공하고 있습니다.\n\n새 버젼에서는 주소 입력시 서울, 경기, 경북, 전남등 도명을 선택후 도로명을 입력하시면 됩니다.\n(도로명 입력시 해당 지번을 함께 입력하시는 것이 좋습니다.)\n\n구주소를 입력하고자 할때는 도명 하단에 "동이름"을 선택하시면 됩니다.\n\n용량이 커서 인터넷 속도에 따라서 다운로드 시간이 오래 걸릴 수 있습니다.\n\n감사합니다.'
  },
  {
    id: 14,
    title: '최신우편번호(6자리 구주소)',
    description: 'Windows 10/16 호환 설치 패키지',
    category: 'utility',
    fileSize: '1.6MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/zipcode.exe',
    imageUrl: 'https://images.unsplash.com/photo-1586769852836-bc069f19e1b6?w=280&h=180&fit=crop&auto=format',
    content: '가장 최근까지 수정된 우편번호입니다.\n지번주소(동이름)으로 우편번호를 찾을때 사용하는 파일입니다.\n새로운 지번주소로 찾아서 안나오면 설치해 주세요.\n\n- 설치 방법\n위의 ZipCode.exe를 누르시면 압축이 풀립니다.\n기본 폴더는 c:\\여러사람 폴더입니다. 여러사람 기준이므로 다운로드나 다른 폴더에서 사용하시는 분들은 설치시 해당 폴더를 지정해 주십시오.\n\n** 이 파일은 마이크로소프트에서 만든 파일이 아닌 프로그램입니다.'
  },
  {
    id: 15,
    title: 'FreeWheel v2.4 -마우스휠로 스크롤 안되시면 설치해주세요',
    description: 'Windows 10/18 호환 설치 패키지',
    category: 'utility',
    fileSize: '0.5MB',
    version: 'v2.4',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/freewheel.zip',
    imageUrl: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=280&h=180&fit=crop&auto=format',
    content: '휠 마우스 설정 "FreeWheel" v2.4\n\n본 프로그램을 설치하시면 프로그램에서 스크롤이 안되는 문제점이 해결됩니다.'
  },
  {
    id: 16,
    title: '[데이터복구화일 다운받기]',
    description: 'Windows 10/27 호환 설치 패키지',
    category: 'utility',
    fileSize: '0.1MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/dbutil.exe',
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=280&h=180&fit=crop&auto=format',
    content: '프로그램이 제대로 작동하지 않을 때 다운받으셔서 실행하시기 바랍니다.\n\n1. Null값 데이타제거는 엑셀 가져오기등 데이타에 관련된 작업을 하다가 문제가 발생한 경우에 사용\n   프로그램에서 Null데이타가 잘못 사용되었다고 나올때\n\n2. 데이타베이스 압축은 갑자기 PC가 멈추거나 바이러스 감염시 정지된 후 프로그램이 작동되지 않을때 사용\n\n3. 좌우 스페이스(특수문자)제거는 선택된 파일의 스페이스를 지우고 특수문자를 지워줍니다.\n\n* 기본적으로 데이타는 c: 드라이브의 프로그램명\\데이타 폴더에 있습니다.'
  },
  {
    id: 17,
    title: '도로명주소 입력 및 여러사람설치(윈도우7이상) 안내서',
    description: '소프트웨어 Manual',
    category: 'manual',
    fileSize: '1MB',
    version: 'v1.0',
    uploadedAt: '2026-03-10',
    fileUrl: 'https://www.mmsoft.co.kr/program/여러사람설치및사용안내서.doc',
    imageUrl: 'https://images.unsplash.com/photo-1568667256549-094345857637?w=280&h=180&fit=crop&auto=format',
    content: '본 사용안내서는 기존 매뉴얼 외에 윈도우7이상 버젼에서 관리자 권한으로 설치하는 방법과 새도로명주소와 우편번호5자리 체계에 맞춰 입력하는 방법을 설명하는 추가 설명서 입니다.\n\n기존 매뉴얼은 홈페이지 또는 프로그램 상단 도움말-설명서 메뉴에 있습니다.\n\n마이크로소프트 워드로 작성되어 있습니다.\n인터넷상에서 직접 열어보시거나 저장하신 후 MS워드가 설치된 컴퓨터에서 보거나 인쇄할 수 있습니다.\n\n감사합니다.'
  }
];

// 카테고리 목록
export const DOWNLOAD_CATEGORIES = [
  { id: 'all',      label: '전체',      value: 'all' },
  { id: 'software', label: '소프트웨어', value: 'software' },
  { id: 'utility',  label: '유틸리티',  value: 'utility' },
  { id: 'manual',   label: '매뉴얼',    value: 'manual' }
];
